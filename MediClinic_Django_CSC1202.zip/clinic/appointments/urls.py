from django.urls import path
from . import views

urlpatterns = [
    # Public
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('doctors/', views.doctor_list, name='doctor_list'),
    path('feedback/', views.feedback_view, name='feedback'),

    # Patient
    path('dashboard/', views.dashboard, name='dashboard'),
    path('appointments/book/', views.book_appointment, name='book_appointment'),
    path('appointments/my/', views.my_appointments, name='my_appointments'),
    path('appointments/<int:pk>/cancel/', views.cancel_appointment, name='cancel_appointment'),
    path('medical-history/', views.medical_history, name='medical_history'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),

    # Admin
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin/appointments/', views.manage_appointments, name='manage_appointments'),
    path('admin/appointments/<int:pk>/update/', views.update_appointment, name='update_appointment'),
    path('admin/doctors/', views.manage_doctors, name='manage_doctors'),
    path('admin/doctors/add/', views.add_doctor, name='add_doctor'),
    path('admin/doctors/<int:pk>/edit/', views.edit_doctor, name='edit_doctor'),
    path('admin/doctors/<int:pk>/delete/', views.delete_doctor, name='delete_doctor'),
    path('admin/patients/', views.manage_patients, name='manage_patients'),
    path('admin/records/', views.manage_records, name='manage_records'),
    path('admin/records/add/', views.add_record, name='add_record'),
    path('admin/feedbacks/', views.view_feedbacks, name='view_feedbacks'),
]
